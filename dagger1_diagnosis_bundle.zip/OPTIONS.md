# Four options for the generation gap

This document covers **cause A only** — the starved recovery strata that block the
pipeline. Causes B (disposition plumbing) and C (capacity target) are independent and
described in `README.md`; neither requires the decision below.

---

## The constraint that forces a choice

A DAgger-1 row becomes training-eligible only by clearing this chain
(`psse_env/dagger/rollout_collector.py:1136`):

```python
if collection_role == "diagnostic":      → diagnostic_beta_zero_not_training_eligible
elif state_origin != "learner_policy":   → not_learner_visited_state
elif recovery_stratum not in _DAGGER1_PRODUCTION_RECOVERY_STRATA:
                                         → not_recovery_state
elif preferred_action is None:           → missing_expert_target
elif not training_decision_evidence_verified: ...
elif rank_one_target_proof.get("passed") is not True: ...
```

Counterfactual rows die at **check 2**. An injected mistake comes from
`plausible_wrong_actions`, not from the learner's policy, so `state_origin` is
legitimately not `learner_policy`.

**That check is load-bearing, not bureaucratic.** DAgger's justification is that the
learner is trained on the state distribution its own policy induces. Injected states are
not drawn from that distribution.

D0 already respects this: `generate_round0_aggregate.py:2941` writes `eligible_rows` and
`auxiliary_rows` to **separate files**. Counterfactuals are auxiliary there by design —
deliberately outside the training set. Porting the stream alone therefore changes
nothing; the rows would land in an auxiliary file and still count toward no floor.

Also note the collection loop comment at `rollout_collector.py:1036`, which states the
exclusion is intentional and names the destination:

> *"Deliberate exploration belongs in the counterfactual or ranking pipelines, where the
> executed target is recorded explicitly."*

---

## Option A — label injected states as `learner_policy`

Set `state_origin = "learner_policy"` on counterfactual rows so they pass check 2.

- **Effort:** trivial, one line.
- **Cost:** falsifies provenance. The audit trail would assert these states were visited
  by the learner when they were synthesised. It silently breaks the DAgger guarantee the
  whole pipeline is built to protect, and does so invisibly — nothing downstream could
  detect it.
- **Assessment:** **not recommended.** It buys a green gate by making the evidence untrue.

## Option B — new `state_origin`, admitted explicitly

Introduce `state_origin = "counterfactual_injection"`, add an explicit eligibility branch
admitting it, and count those rows toward the strata floors.

- **Effort:** moderate. See mechanical scope below.
- **Cost:** changes what "DAgger-1 training data" means — you are training partly on
  synthetic mistakes rather than purely on learner-induced states. That is a real
  departure from DAgger's theoretical footing and should be written into the contract,
  not left implicit.
- **Benefit:** honest and auditable. Provenance stays accurate, the departure is explicit
  and greppable, and reviewers can see exactly which rows are synthetic.
- **Assessment:** **recommended as the unblocking path**, paired with D as a review item.

## Option C — keep rows auxiliary, amend only the gates

Leave counterfactual rows out of training (as D0 does) but change the gates to count them
toward the distinct-root floors.

- **Effort:** low.
- **Cost:** the floors would be satisfied by rows that never train anything. The gate
  exists to guarantee the training set covers these recovery situations; passing it with
  non-training rows defeats its purpose while leaving the appearance of coverage.
- **Assessment:** **not recommended.** This is gaming the gate.

## Option D — revisit the floors themselves

Ask whether a 10-distinct-root floor on these two strata is coherent.

- **The argument:** at β=0.25 the learner produced 3 rows per starved stratum across 1600
  visited states — a ~0.2% yield. And it gets *worse* every iteration, because the point
  of DAgger is that the learner stops making these mistakes. A floor on situations the
  method is designed to eliminate tightens as the pipeline succeeds.
- **Supporting evidence:** `invalid_precondition_repair` is a declared production stratum
  that fired **zero** times in 1600 rows. At least one floor in this contract is already
  structurally unfillable.
- **Effort:** low in code, high in review — it is a contract change requiring sign-off.
- **Assessment:** **possibly the correct answer.** It is the question a reviewer will ask
  regardless, and it would make most of the Option B work unnecessary.

---

## Recommendation

**B to unblock, with D raised explicitly for review.** B restores forward progress with
accurate provenance; D asks whether the requirement was right in the first place. Settle
B-vs-D *before* writing code — choosing D makes most of items 4–6 below unnecessary.

---

## Mechanical scope (assuming B)

The generator API is clean and reusable as-is:

```python
generator = CounterfactualGenerator(env=env, expert_oracle=oracle)
rows = generator.generate_from_current(
    injected, root_scenario_id=..., physical_root_fingerprint=...)
```

| # | Work | Notes |
|---|---|---|
| 1 | Lift `_bounded_injected_actions` into a shared module | `generate_round0_aggregate.py:458`, ~20 lines, currently private |
| 2 | Wire generator into `collect_dagger1.py` | add `--counterfactuals-per-root` (D0 defaults to 3); mirror `generate_round0_aggregate.py:976`; dedicated derived RNG |
| 3 | New `state_origin` + eligibility branch in `rollout_collector.py` | the stratum classifier needs **no** change — D0 data proves both predicates already fire on post-injection observations |
| 4 | **Schema bridge — the largest chunk** | see below |
| 5 | Gates admit the new origin | `deterministic_collection_selection`, `independent_root_support`, `targeted_state_coverage` |
| 6 | Manifests + SHA256SUMS | pipeline is hash-bound throughout (`input_sha256`, `scenario_manifest_sha256`, `d0_manifest_sha256`) |
| 7 | Tests | `test_collect_dagger1.py` (2208 lines), `test_dagger1_builders.py` (1855) encode these contracts directly |

**Schema bridge (item 4).** D0 counterfactual rows carry `branch_family`,
`injected_action`, `injected_tool_output`, `injection_transition`, `recovery_output`,
`continuation_actions`. They lack nearly every DAgger-1 field that the gates read:

```
recovery_stratum          state_origin              collection_batch_id
collection_role           collection_beta           collection_disposition
collection_rollout_replica  collection_rollout_seed  iteration
step                      transition_label          next_valid_actions
terminal_outcome          supervision_policy        recovery_label_contract
production_label_ineligibility_reason               observable_rank_one_target_proof
offline_teacher_target_audit
```

**Determinism.** `_bounded_injected_actions` uses `rng.choice`/`rng.shuffle`. D0 threads a
dedicated `counterfactual_rng`; DAgger-1 must derive its own from `--seed` so reruns stay
byte-identical. This pipeline compares hashes everywhere.

**Root safety.** Branches clone from the same fresh root, so `physical_root_fingerprint`
stays inside the fresh set. No new forbidden-root exposure.

**`executed_by`.** Currently `"expert"` or `"model"`. Injected rows are neither and need a
third value; anything auditing that field needs updating.

---

## Yield projection

D0 rates applied to DAgger-1's 102 eligible fresh roots, at `--counterfactuals-per-root 3`:

| Stratum | D0 rate | Projected roots | Floor | Headroom |
|---|---|---|---|---|
| `post_failure_no_candidate` | 263/263 roots (100%) | ~102 | 10 | ~10× |
| `unsupported_correction_recovery` | 152/263 roots (58%) | ~59 | 10 | ~6× |

The estimate can be substantially wrong and still clear.

**Known gap:** only two of the four unsupported codes actually fire in D0 —
`correction_not_supported_by_current_context` (164) and `correction_route_not_actionable`
(48); `parameter_scans_missing` and `post_correction_confirmation_required` are absent.
The stratum accepts any of the four so the floor is still reachable, but full four-route
coverage would need injector work. `parameter_scans_missing` may be absent deliberately —
`diagnostic_suite.py:152` says the design "must prevent the old numerical
`parameter_scans_missing` path."

---

## Validation

The diagnostic pass cannot validate this: check 1 makes β=0 training-ineligible by rule.
Run a training pass and read stratum counts from the `--all-output` audit JSONL before
anything publishes — the same file this diagnosis was built from.

## Suggested sequencing

1. **Fix C first** (retarget 1630 → 1521). Config only, clears one of five gates.
2. **Fix B** (disposition plumbing). Contained, and it carries an ongoing training-quality
   cost independent of this run.
3. **Decide B-vs-D** for the generation gap.
4. **Implement**, then validate via a training pass as above.
